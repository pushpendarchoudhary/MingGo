const ConsumptionTrackingContract = artifacts.require("ConsumptionTrackingContract");

contract("ConsumptionTrackingContract", (accounts) => {
    const artworkHash = web3.utils.sha3("ArtworkFileContent");
    const streamRate = 1; // Example rate per stream
    const downloadRate = 5; // Example rate per download

    it("should record a stream successfully", async () => {
        let instance = await ConsumptionTrackingContract.deployed();
        await instance.recordStream(artworkHash, { from: accounts[0] });

        let streamCount = await instance.getStreamCount(artworkHash);
        assert.equal(streamCount.toNumber(), 1, "Stream count should be 1");
    });

    it("should record a download successfully", async () => {
        let instance = await ConsumptionTrackingContract.deployed();
        await instance.recordDownload(artworkHash, { from: accounts[0] });

        let downloadCount = await instance.getDownloadCount(artworkHash);
        assert.equal(downloadCount.toNumber(), 1, "Download count should be 1");
    });

    it("should calculate payment correctly", async () => {
        let instance = await ConsumptionTrackingContract.deployed();
        await instance.recordStream(artworkHash, { from: accounts[1] });
        await instance.recordDownload(artworkHash, { from: accounts[1] });

        let totalPayment = await instance.calculatePayment(artworkHash, streamRate, downloadRate);
        assert.equal(totalPayment.toNumber(), 6, "Total payment should be 6");
    });
});
