const ArtworkManagementContract = artifacts.require("ArtworkManagementContract");
const ConsumptionTrackingContract = artifacts.require("ConsumptionTrackingContract");

contract("ArtworkManagementContract", (accounts) => {
    const artworkHash = web3.utils.sha3("ArtworkFileContent");

    it("should register an artist", async () => {
        let instance = await ArtworkManagementContract.deployed();
        await instance.registerArtist({ from: accounts[0] });

        let isArtist = await instance.isArtist(accounts[0]);
        assert.equal(isArtist, true, "User should be registered as an artist");
    });

    it("should submit an artwork", async () => {
        let instance = await ArtworkManagementContract.deployed();
        await instance.submitArtwork("Title", "Artist", "Genre", artworkHash, "metadataURI", { from: accounts[0] });

        let artwork = await instance.artworks(artworkHash);
        assert.equal(artwork.title, "Title", "Artwork title should match");
    });

    it("should publish an artwork and initialize consumption tracking", async () => {
        let artworkInstance = await ArtworkManagementContract.deployed();
        let consumptionInstance = await ConsumptionTrackingContract.deployed();

        await artworkInstance.publishArtwork(artworkHash, { from: accounts[0] });

        let artwork = await artworkInstance.artworks(artworkHash);
        assert.equal(artwork.isPublished, true, "Artwork should be published");

        let consumption = await consumptionInstance.artworkConsumption(artworkHash);
        assert.equal(consumption.streamCount.toNumber(), 0, "Stream count should be initialized to 0");
        assert.equal(consumption.downloadCount.toNumber(), 0, "Download count should be initialized to 0");
        assert.equal(consumption.initialized, true, "Artwork should be marked as initialized");
    });
});
