const ArtworkManagementContract = artifacts.require("ArtworkManagementContract");
const ConsumptionTrackingContract = artifacts.require("ConsumptionTrackingContract");

module.exports = async function(deployer) {
    await deployer.deploy(ConsumptionTrackingContract);
    const consumptionInstance = await ConsumptionTrackingContract.deployed();

    await deployer.deploy(ArtworkManagementContract, consumptionInstance.address);
};
